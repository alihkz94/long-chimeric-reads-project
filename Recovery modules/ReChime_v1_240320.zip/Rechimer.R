#!/usr/bin/env Rscript

## Load packages
cat("Loading R packages:\n")

load_pckg <- function(pkg = "data.table"){
  suppressPackageStartupMessages( library(package = pkg, character.only = TRUE) )
  cat(paste("  ", pkg, packageVersion(pkg), "\n"))
}

load_pckg("optparse")
load_pckg("data.table")
load_pckg("plyr")
load_pckg("Biostrings")

cat("\n")

cat("Parsing command-line arguments\n")

## Parse arguments
option_list <- list(

  make_option(
    c("-i", "--input_nonchimeric"),
    action="store",
    default="rechime_nonchimeric_ids.txt.gz",
    type='character',
    help="Input files (from `seqkit stat`)"),

  make_option(
    c("-u", "--input_chimeric"),
    action="store",
    default="rechime_chimeric_ids.txt.gz",
    type='character',
    help="Input files (from `seqkit stat`)"),

  make_option(
    c("-c", "--chimeradir"),
    action="store",
    default="./chimeras",
    type='character',
    help="Output file with bucket contents"),

  make_option(
    c("-o", "--outdir"),
    action="store",
    default="./ReChimed",
    type='character',
    help="Output file with bucket contents"),

  make_option(
    c("-m", "--minocc"),
    action="store",
    default=2L,
    type='integer',
    help="Output file summary information")
)
opt <- parse_args(OptionParser(option_list=option_list))


# Validation of the required argiments
cat("..Argument validation\n")

if(is.na(opt$input_nonchimeric)){
  stop("ERROR: Input file with non-chimeric data is not specified\n")
}
if(is.na(opt$input_chimeric)){
  stop("ERROR: Input file with chimeric data is not specified\n")
}
if(is.na(opt$chimeradir)){
  stop("ERROR: Directory with chimeric files is not specified\n")
}
if(is.na(opt$outdir)){
  stop("ERROR: Output directory is not specified\n")
}
if(is.na(opt$minocc) | opt$minocc < 1){
  stop("ERROR: Misspecified number of minimal occurrences\n")
}


######## Main workflow

MINOCC <- opt$minocc   # Minimal occurrence

## Direcotory names
chims <- opt$chimeradir  # "./chimeras" by default, contains chimeric sequences
recov <- opt$outdir      # "./ReChimed" by default, will contain the recovered sequences

## Create output dir
dir.create(path = recov, showWarnings = FALSE, recursive = TRUE)


cat("\nLoading input data\n")

## Load data
CC <- fread(
  file = "rechime_chimeric_ids.txt.gz",
  sep = NULL, header = FALSE)

NC <- fread(
  file = "rechime_nonchimeric_ids.txt.gz",
  sep = NULL, header = FALSE)

## Split by columns
CC[ , c("FileID", "SeqHash", "SeqHeader") := tstrsplit(x = V1, split = "____", keep = 1:3) ]
NC[ , c("FileID", "SeqHash", "SeqHeader") := tstrsplit(x = V1, split = "____", keep = 1:3) ]

CC[ , V1 := NULL ]
NC[ , V1 := NULL ]

CC[ , FileType := "chimeric" ]
NC[ , FileType := "nonchimeric" ]

cat("Processing data\n")

## Subset to the sequences identified as putative chimera
## (to decrease the size of the dataset)
NC <- NC[ SeqHash %in% unique(CC$SeqHash) ]

## Estimate global sequence occurrence
OCC <- rbind(CC, NC)[ , .(TotalOccurrence = .N), by = "SeqHash" ]

## Find sequences with high occurrence
OCC <- OCC[ TotalOccurrence >= MINOCC ]

## Identify which sequences and in which samples should be recovered
RC <- CC[ SeqHash %in% OCC$SeqHash ]


if(nrow(RC) < 1){

  cat("No sequences for recovery\n")

} else {

## Split by file ID
RC <- split(x = RC, f = RC$FileID)

cat("Recovering and exporting sequences\n")

## Function to extract and save the recovered sequences
seq_recover <- function(x){

  ## Load the file with chimeric seqs
  sqs <- readDNAStringSet(
    filepath = file.path(chims, x$FileID[1]) )

  ## Subset to the recoverable sequences
  sqs <- sqs[ x$SeqHeader ]

  ## Export results
  if(length(sqs) > 0){

    writeXStringSet(
      x = sqs,
      filepath = file.path(recov, x$FileID[1]),
      compress = FALSE,
      format = "fasta",
      width = 9999)

  } else {
    cat("WARNING: no sequences for recovery found in the FASTA file.\n")
    cat("WARNING: check the FASTA header.\n")
  }

  stats <- data.table(
    FileName      = x$FileID[1],
    SeqsRecovered = length(sqs))

  return(stats)
}

## Process all chimeric files
stats <- ldply(
  .data = RC,
  .fun = seq_recover,
  .progress = "text",
  .id = NULL)

## Show the stats on screen
cat("\nRecovery stats\n")
print(stats)

}  # End of sequence recovery

cat("\nAll done.\n")
